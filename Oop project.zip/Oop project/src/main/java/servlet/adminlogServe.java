package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.customer;
import services.logadmin;
import java.io.IOException;

public class adminlogServe extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public adminlogServe() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        logadmin userDAO = new logadmin();
        customer user = userDAO.getUserByEmailAndPassword(email, password);

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email); // Store user's email in session for future use
            RequestDispatcher dis = request.getRequestDispatcher("adminDashboard.jsp");
            dis.forward(request, response);
        } else {
            // If user is not valid, redirect back to login page
            response.sendRedirect("adminLog.jsp?error=invalid");
        }
    }
}
