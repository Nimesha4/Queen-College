package servlet;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import model.customer;
import services.adminEditService;

public class adminEdit extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Instantiate the service class
        adminEditService service = new adminEditService();
        
        // Retrieve all customers from the database
        List<customer> customers = service.getAllCustomers();

        // Set customers as an attribute in the request to pass it to the JSP page
        request.setAttribute("customerss", customers);

        // Forward the request to the Tdetails.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("adminDetails.jsp");
        dispatcher.forward(request, response);
    }

}
