package services;

import java.sql.Statement;

import controller.DBConnect;

public class childService {
	public boolean regChild (String id , String name , String address , String email , String password , String grade ) {
			
			boolean isSucc = false ;
			
			try {
				
				String query = "insert into schoolchild values('"+id+"' ,'"+name+"' , '"+email+"' , '"+address+"' , '"+password+"' , '"+grade+"' ) ";
				
				Statement stat = DBConnect.getConnection().createStatement();
				int rd = stat.executeUpdate(query);
				
				if (rd > 0) {
					isSucc = true ;
				}
				else
				{
					isSucc = false ;
				}
				
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
			return isSucc;
		}
	}
	
