package services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import controller.DBConnect;

public class TeacherUpdateService {

    public static boolean updateTeacher(String id, String name, String email, String address, String number) throws ClassNotFoundException, SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBConnect.getConnection();

            String sql = "UPDATE details SET name=?, email=?, address=?, number=? WHERE id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, address);
            pstmt.setString(4, number);
            pstmt.setString(5, id);

            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0;
        } finally {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
    }
}
