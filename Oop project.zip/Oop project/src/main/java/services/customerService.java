package services;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.customer;
import controller.DBConnect;

public class customerService {
	public static boolean regCustomer (String id , String name , String address , String email , String number , String password) {
		
		boolean isSuccess = false ;
		
		try {
			
			String query = "insert into details values('"+id+"' ,'"+name+"' , '"+email+"' , '"+address+"' , '"+password+"' , '"+number+"' ) ";
			
			Statement statement = DBConnect.getConnection().createStatement();
			int rs = statement.executeUpdate(query);
			
			if (rs > 0) {
				isSuccess = true ;
			}
			else
			{
				isSuccess = false ;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
		
	}
	
	//update customer
		//use parameters from updateCustomerServlet
		public static boolean updatecustomer(String id,String name, String email, String address, String password,String number ) {
			boolean isSuccess= false;
			
		//create database connection
		try {
			Statement statement = DBConnect.getConnection().createStatement();
			//write update query
			String sql="update customer set name='"+name+"',email='"+email+"',address='"+address+"',number='"+number+"',password='"+password+"' "
					   + "where id= '"+id+"'";
			
			int rs = statement.executeUpdate(sql);
			
			if(rs > 0) {
				isSuccess = true;
			}
			else {
				isSuccess= false;
			}
			
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		
		
		
		return isSuccess;
	}
		
		public static List<customer> getCustomerDetails(String Email){
			
			
			
			ArrayList<customer> cus= new ArrayList<>();
			
			try {
				Statement statement = DBConnect.getConnection().createStatement();
				String sql ="select * from details where email='"+Email+"'"; 
				ResultSet rs= statement.executeQuery(sql);
				
				while(rs.next()) {
					
	                String id = rs.getString(1);
	                String name = rs.getString(2);
	                String email = rs.getString(3);
	                String address = rs.getString(4);
	                String password = rs.getString(5);
	                String number = rs.getString(6);
	                
					
	                customer c = new customer(id , name , email , address , password , number);
					cus.add(c);
					
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			
			
			return cus;
		}
	
	
}
